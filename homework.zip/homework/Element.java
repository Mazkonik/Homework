package lesson_3.homework;

public interface Element {

    void click();
}
