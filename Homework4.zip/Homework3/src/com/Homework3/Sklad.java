package com.Homework3;


import java.util.ArrayList;
import java.util.Scanner;

public class Sklad {

}
